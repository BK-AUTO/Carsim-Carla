import numpy as np
class DriverModels:
    def __init__(self):
        self.PIN_output = 0  # Initialize PIN_output
    
    def workspace(self, time_s):
        waypoints = [
        (0,   0), (4,   15), (10,  32), (40,  50),
        (65,  30), (80,  10), (120, 0), (124, 20),
        (150, 50), (200, 30), (240, 0), (244, 20),
        (270, 50), (300, 30), (360, 0), (364, 20),
        (390, 50), (420, 30), (480, 0), (484, 20),
        (510, 50), (540, 30), (600, 0), (604, 20),
        (630, 50), (660, 30), (720, 0), (724, 20),
        (750, 50), (780, 0), (790, 50), (830, 90),
        (940, 120), (1020, 90), (1100, 50), (1180, 0)
        ]
        wp_times = np.array([pt[0] for pt in waypoints])
        wp_speeds = np.array([pt[1] for pt in waypoints])
    
        # Clip input time to cycle range
        t = np.clip(time_s, wp_times.min(), wp_times.max())
        workspace_velocity = np.interp(t, wp_times, wp_speeds)
        return workspace_velocity
    
    def desire_components(self,time_s):
        desire_velocity = self.workspace(time_s)
        # Calculate acceleration as change in velocity over time
        if not hasattr(self, 'prev_velocity'):
            self.prev_velocity = desire_velocity
            self.delta_t = 0.1  # Default time step in seconds
            desire_acceleration = 0  # Initial acceleration
        else:
            desire_acceleration = (desire_velocity - self.prev_velocity) / self.delta_t
            self.prev_velocity = desire_velocity
        # Calculate distance by integrating velocity
        if not hasattr(self, 'prev_distance'):
            self.prev_distance = 0  # Initialize distance
            desire_distance = self.prev_distance + (desire_velocity * self.delta_t)
        else:
            desire_distance = self.prev_distance + (desire_velocity * self.delta_t)
        return desire_velocity, desire_acceleration, desire_distance
    
    def PIN(self, velocity, PID_s):
        P = PID_s 
        if velocity <= 0.05 and P < 0:
            P = 0
        return P
        
    def PID(self, input_val=1):
        workspace_velocity = self.workspace()
        PID_s = workspace_velocity - self.velocity
        
        if input_val == 1:
            self.PIN_output = self.PIN(self.velocity, PID_s)
        elif input_val == 2:
            self.PIN_output = self.PIN(self.velocity, 1)
        else:
            print("Error: Invalid input for PIN")
        return self.PIN_output
        
    def get_outputs(self):
        Pedal_postion = self.PIN_output
        return Pedal_postion   