class FrontMotorModels:
    def __init__(self, w_fmotor, w_rmotor, battery, t_fbberq, t_rbberq, omega_equivalent, T_max):
        self.w_fmotor = w_fmotor
        self.w_rmotor = w_rmotor 
        self.battery = battery
        self.t_fbberq = t_fbberq
        self.t_rbberq = t_rbberq
        self.T_max = T_max    
        self.omega_equivalent = omega_equivalent
        self.rt = w_rmotor
    def Triple_phase_PMSM_models(self):
        def Maximum_torque(w_fmotor, omega_equivalent, T_max):    
            N_e = w_fmotor * T_max
            M_e = (omega_equivalent * T_max) / w_fmotor 
            if w_fmotor > omega_equivalent:
                return M_e
            elif w_fmotor <= omega_equivalent: 
                return N_e
            else:
                # This case is logically unreachable but added for safety
                print("Error: Invalid motor speed")
                return 0
        def Front_torque (battery, t_fbberq, w_fmotor, omega_equivalent, T_max):
            if battery > 0:
                ft = Maximum_torque(w_fmotor, omega_equivalent, T_max)
            elif battery <= 0:
                ft = -1 * t_fbberq
            else:
                # This case is logically unreachable but added for safety
                print("Error: Invalid battery status")
                ft = 0
            return ft    
        def Rear_torque (battery, t_rbberq, w_rmotor, omega_equivalent, T_max):
            if battery > 0:
                rt = Maximum_torque(w_rmotor, omega_equivalent, T_max) * 0.5
            elif battery <= 0:
                rt = -1 * t_rbberq
            else:
                # This case is logically unreachable but added for safety
                print("Error: Invalid battery status")
                rt = 0
            return rt
        FRP = Front_torque(self.battery, self.t_fbberq, self.w_fmotor, self.omega_equivalent, self.T_max) * self.w_fmotor
        RRP = Rear_torque(self.battery, self.t_rbberq, self.w_rmotor, self.omega_equivalent, self.T_max) * self.w_rmotor

        self.ft = Front_torque(self.battery, self.t_fbberq, self.w_fmotor, self.omega_equivalent, self.T_max)
        self.rt = Rear_torque(self.battery, self.t_rbberq, self.w_rmotor, self.omega_equivalent, self.T_max)
        return FRP, RRP
    def get_outputs(self):
        self.FRP, self.RRP = self.Triple_phase_PMSM_models()
        # self.rt and self.ft are set in Triple_phase_PMSM_models
        return self.FRP, self.RRP, self.rt, self.ft
    


    

