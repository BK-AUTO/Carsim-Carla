# Fix imports
from front_tier_vehical_model import FrontTireVehicleModel
from front_motor_models import FrontMotorModels
from battery_models import BatteryModels
from rear_tier_vehical_model import RearTireVehicleModel
from break_model_subsystem1 import BreakModel_subsystem_1, BreakModel_subsystem_2
from vehical_models import VehicleModel
from driver_models import DriverModels
import numpy as np
import pandas as pd
# Instantiate each model
# Provide required parameters for FrontTireVehicleModel
# First instantiate the vehicle model to get acceleration data

def global_value():
    # Global variables
    global dt, i_hs, n_hs, J_m, J_gb, J_whf, J_whr, J_fd, r_wh, m, l, l_f, l_r, h
    global g, id, f, phiMax, tileT, tileS, tileSP, T_brmax, A, Cw, ro, Clco
    global Mott, Motr, tau_d, Thw, a, b, Tmax, Tau2, Tau_Br, beta
    global I_SOC, C, values, SOC_V, Vb_values, Vb, SOC_Rin_values, SOC_Rin, Rint
    global LoadRatio, EffMt, EffGer, Eff_bat, omegac, omegaMax, L, Beta, G, Fb_max
    
    dt = 0.02
    i_hs = 10.418
    n_hs = 0.95
    J_m = 0.01
    J_gb = 0.0196
    J_whf = 0.95*2
    J_whr = 0.95*2
    J_fd = 0.07
    r_wh = 0.36505
    m = 2530
    l = 2.950
    l_f = l * 0.51
    l_r = l * 0.49
    h = 0.65

    # Load tire data (replace with appropriate method)
    # Tire = pd.read_excel('tiremodel.xlsx')
    # Slip = Tire.iloc[:, 0].values
    # Roadmu = Tire.iloc[:, 1].values

    g = 9.81                      
    id = 0                        
    f = 0.016                     
    phiMax = 0.9
    # ti le phan chia
    tileT = 0.5
    tileS = 1
    tileSP = 1
    T_brmax = 0.8*m*9.81*r_wh         
    A = 0.8*1.934*1.667          
    Cw = 0.23                     
    ro = 1.24
    Clco = 1                      

    # Load motor data (replace with appropriate method)
    # Mot = pd.read_excel('motorR.xlsx')
    Mott = np.concatenate([np.arange(-400, -19, 20), np.arange(20, 401, 20)])
    Motr = np.arange(600, 3501, 100)

    # Td=350
    tau_d = 0.05
    Thw = 2
    a = 0.7   
    b = 0.3   
    Tmax = 520
    Tau2 = 0.02
    # T_Br_max=200
    Tau_Br = 0.1
    beta = 0.4

    # Battery Parameters
    # Internal Resistance
    I_SOC = 100
    C = 231.7

    values = np.array([0.0866, 0.4808, 1.2521, 2.3660, 3.4457, 5.2623, 7.3188, 10.0266, 12.1859,
                    17.0014, 19.9832, 23.6505, 27.1466, 30.5912, 36.0581, 39.9825, 41.7135, 42.7589,
                    44.2155, 45.4837, 46.7005, 47.9001, 49.0998, 50.0939, 51.0538, 52.0480, 53.1280,
                    53.9853, 54.7055, 55.3573, 56.0950, 57.1245])
    SOC_V = np.flip((66.2-values)/66.2*100)

    Vb_values = np.array([398.6599, 396.4386, 394.4717, 392.5215, 391.0414, 389.1257, 387.3396, 384.0524, 382.5072,
                        380.1487, 378.6438, 376.5829, 374.1598, 371.7341, 367.4028, 363.4677, 361.0761, 359.5941,
                        358.4863, 357.8409, 356.7213, 355.6008, 353.0652, 348.9865, 343.6090, 336.8181, 327.0832,
                        317.4554, 306.2879, 292.8763, 272.3936, 242.6092])
    Vb = np.flip(Vb_values+65)

    SOC_Rin_values = np.array([6.6549, 13.2164, 19.8875, 26.4705, 39.7252, 46.3303, 52.9553])
    SOC_Rin = np.flip((66.2-SOC_Rin_values)/66.2*100)
    Rint = np.flip(np.array([0.1453, 0.1358, 0.1394, 0.1446, 0.1398, 0.1418, 0.2028]))

    # Motor Parameters
    LoadRatio = np.array([0.01, 0.02, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.0])
    EffMt = np.array([58.72, 72.24, 83.89, 88.67, 91.28, 92.12, 92.71, 93.31, 93.91, 94.51, 94.43, 93.67, 92.91])
    EffGer = np.array([56.62, 70.63, 83.02, 88.20, 91.04, 91.98, 92.56, 93.14, 93.71, 94.29, 94.74, 94.07, 93.41])

    Eff_bat = 0.95
    Tmax = 250
    omegac = 628.32      
    omegaMax = 1675.52   
    Tau2 = 0.02

    ## Generating the elements in the arrays
    L = 2.95
    a = 0.51*L
    b = 0.49*L    
    h = 0.65
    Beta = 0.692
    Fb_max = T_brmax/r_wh
## Running all functions in each models
# Initialize global variables
global_value()
##Running all init functions

# Instantiate all models
time_s = input("Enter the time in seconds: ")
try:
    time_s = float(time_s)
except ValueError:
    print("Invalid input for time. Please enter a number.")
    exit(1)
driver_model = DriverModels()
workspace_velocity = driver_model.workspace(time_s)
desire_velocity, desire_acceleration, desire_distance = driver_model.desire_components(time_s)
front_tire_model = FrontTireVehicleModel(m, l_f, l_r, h, g, desire_acceleration)


