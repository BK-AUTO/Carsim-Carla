import numpy as np
from scipy.interpolate import interp1d


class BatteryModels:
    def __init__(self, RRP, FRP):
        self.RRP = RRP
        self.FRP = FRP
        self.maximum_motory_power = (2 * 130) * 2
    def compare_front_rear_raito(self,front,rear):
        r_f = front / (front + rear)
        r_r = rear / (front + rear)
        front_raito = r_f
        rear_raito = r_r
        return front_raito, rear_raito
    def lockupfunction_SOC_percent(self, SOC_V, Vb):
        interpolate_SOC_percent_to_U_bat = interp1d(SOC_V, Vb, fill_value="extrapolate", kind='linear')
        return interpolate_SOC_percent_to_U_bat
    def lockupfunction_internal_resistor(self,SOC_Rin, Rint):
        interpolate_SOC_Rin_to_Rint = interp1d(SOC_Rin, Rint, fill_value="extrapolate", kind='linear')
        return interpolate_SOC_Rin_to_Rint
    def lockupfunction_internal_resistor_from_China(self, SOC_Rin_China = [0 ,20 ,40 ,60, 80], Rint_China = [0.037, 0.036, 0.035, 0.0345, 0.034, 0.0348]):
        interpolate_SOC_Rin_to_Rint_China = interp1d(SOC_Rin_China, Rint_China, fill_value="extrapolate", kind='linear')
        return interpolate_SOC_Rin_to_Rint_China
    def lockupfunction_rear_motor_efficiency(self, LoadRaito, EffMt):
        interpolate_rear_motor_efficiency = interp1d(LoadRaito, EffMt, fill_value="extrapolate", kind='linear')
        interpolate_front_motor_efficiency = interp1d(LoadRaito, EffMt, fill_value="extrapolate", kind='linear')
        return interpolate_rear_motor_efficiency, interpolate_front_motor_efficiency
    def SOC_equations(self, SOC_int, battery_current, battery_capacity, SOC_V, Vb):
        # Assuming battery_current is an array of current values and integration is over time step dt
        # You may need to pass 'dt' as an argument or define it elsewhere
        # Example with simple trapezoidal integration:
        battery_current_integral = np.trapezoid(battery_current)  # Integrate over the array
        SOC = SOC_int * 0.01 - (1 / battery_capacity) * (battery_current_integral)
        SOC_percent = SOC * 100
        lockup_func = self.lockupfunction_SOC_percent(SOC_V, Vb)
        battery_voltage = lockup_func(SOC)
        if SOC < 0.1 or SOC == 0:
            battery_voltage = 0
            SOC_percent = 0
        return battery_voltage, SOC_percent
    def regenerative_energy(self, battery_current, battery_voltage):
        regen_power = -(abs(battery_current * battery_voltage))*(1/3600)
        regen_energy = abs(np.trapezoid(regen_power) * (1/1000))
        total_engery_comsumption = np.trapezoid(battery_current * battery_voltage * (1/3600))*(1/1000)
        regen_capcaity = regen_energy / (battery_voltage * 1000)
        return regen_power, regen_energy, total_engery_comsumption, regen_capcaity
    def rt_value(self, SOC_percent, SOC_Rin, Rint, SOC_Rin_China=None, Rint_China=None):
        internal_resistor = self.lockupfunction_internal_resistor(SOC_Rin, Rint)(SOC_percent)
        internal_resistor_China = self.lockupfunction_internal_resistor_from_China()(SOC_percent)
        Rt1 = internal_resistor
        Rt2 = internal_resistor_China
        return Rt1, Rt2
    def Pyc_component(self, Rear_motor_maximum_power, Front_motor_maximum_power, RRP, FRP, LoadRaito, EffMt):
        rear_motor_torque = RRP / Rear_motor_maximum_power
        front_motor_torque = FRP / Front_motor_maximum_power
        interpolate_rear, interpolate_front = self.lockupfunction_rear_motor_efficiency(LoadRaito, EffMt)
        HSCS = interpolate_rear(abs(rear_motor_torque)) * (1/100)
        HSCT = interpolate_front(abs(front_motor_torque)) * (1/100)
        Poutput_rear = HSCS * RRP
        Poutput_front = HSCT * FRP
        PycS = RRP*1000 / HSCS
        PycT = FRP*1000 / HSCT
        Pyc = PycS + PycT
        return Pyc, Poutput_rear, Poutput_front
    def battery_equations(self, Rt1, Rt2, Pyc, battery_voltage, RRP, FRP, Poutput_rear, Poutput_front):
        motor_power_loss_from_resistor = (RRP - Poutput_front) + (FRP - Poutput_rear)
        def Current_calculation(Rt, Pyc, battery_voltage):
            I_out = 0
            a = Rt
            b = (-1 * battery_voltage)
            c = Pyc
            delta = b**2 - 4*a*c
            if delta >= 0:
                I_out1 = (-b + np.sqrt(delta)) / (2*a)
                I_out2 = (-b - np.sqrt(delta)) / (2*a)
                if I_out1 >= 0 and I_out2 < 0:
                    I_out = I_out1
                elif I_out2 >= 0 and I_out1 < 0:
                    I_out = I_out2
                elif I_out1 >= 0 and I_out2 >= 0:
                    I_out = min(I_out1, I_out2)  # Choose the smaller positive root
                else:
                    I_out = 0  # Both roots are negative, set current to zero
            else:
                I_out = 0  # No real roots, set current to zero
            return I_out    
        def battery_consumption(Rt, battery_current):
            pinth = Rt * battery_current**2
            return pinth
        choice = input("Choose which internal resistor model to use (1 or 2): ")
        if choice == '1':
            battery_current = Current_calculation(Rt1, Pyc, battery_voltage)
            pinth = battery_consumption(Rt1, battery_current)
        elif choice == '2':
            battery_current = Current_calculation(Rt2, Pyc, battery_voltage)
            pinth = battery_consumption(Rt2, battery_current)
        else:
            raise ValueError("Invalid choice. Please select '1' or '2'.")
        return battery_current, pinth, motor_power_loss_from_resistor
    def front_total_power(self, battery_current, battery_voltage, pinth, HSCT, tileT):
        battery_power = battery_current * battery_voltage
        front_total_power = (battery_power - pinth) * HSCT * tileT
        PmtT = front_total_power
        return front_total_power, PmtT
    def rear_total_power(self, battery_current, battery_voltage, pinth, HSCS, tileS):
        battery_power = battery_current * battery_voltage
        rear_total_power = (battery_power - pinth) * HSCS * tileS
        PmtS = rear_total_power
        return rear_total_power, PmtS
    def front_motor_torque(self, front_total_power, w_fmotor, velocity, accleration,front_raito,Pyc,ft):
        A_P = front_total_power
        R_T = ft
        V = velocity
        A = accleration
        R_P = Pyc * front_raito
        A_T = front_total_power / w_fmotor
        def check_power(A_P, R_T, V, A, R_P):
            Torque = 0
            if A_P < R_P:
                Torque = A_T
                check = 1
            elif R_P < 0:
                Torque = R_T
                check = 0
            elif V < 0.5 and A < 0:
                Torque = 0
            else:
                Torque = R_T
                check = 0
            return Torque, check
        Front_Motor_Torque = check_power(A_P, R_T, V, A, R_P)
        return Front_Motor_Torque
    def rear_motor_torque(self, rear_total_power, w_rmotor, velocity, accleration,rear_raito,Pyc,rt):
        A_P = rear_total_power
        R_T = rt
        V = velocity
        A = accleration
        R_P = Pyc * rear_raito
        A_T = rear_total_power / w_rmotor
        def check_power(A_P, R_T, V, A, R_P):
            Torque = 0
            if A_P < R_P:
                Torque = A_T
                check = 1
            elif R_P < 0:
                Torque = R_T
                check = 0
            elif V < 0.5 and A < 0:
                Torque = 0
            else:
                Torque = R_T
                check = 0
            return Torque, check
        Rear_Motor_Torque = check_power(A_P, R_T, V, A, R_P)
        return Rear_Motor_Torque
    def get_outputs(self, pinth, battery_current,Front_Motor_Torque, Rear_Motor_Torque):
        f_mt = Front_Motor_Torque
        r_mt = Rear_Motor_Torque
        iout = battery_current
        tonhaopin = pinth
        tpTHpin = np.trapezoid(pinth * (1/3600)) * (1/1000)
        tonhaomotor = motor_power_loss_from_resistor
        Nlth = np.trapezoid((tonhaomotor + tonhaopin) * (1/3600)) * (1/1000)
        return tpTHpin, iout, tonhaopin, tonhaomotor, Nlth, f_mt, r_mt
        


       