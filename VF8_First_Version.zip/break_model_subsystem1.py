class BreakModel_subsystem_1:
    def __init__(self, v, battery_output, w_fmotor, w_rmotor, z, t_brmax):
        self.t_brmax = t_brmax
        self.z = z
        self.v = v
        self.battery_output = battery_output
        self.w_fmotor = w_fmotor
        self.w_rmotor = w_rmotor
        self.velocity_related = self.lookup_table_1d(self.v)
        self.front_braking_component = self.look_table_f1d(self.z)
        self.rear_braking_component = self.look_table_r1d(self.z)

    def lookup_table_1d(self, input_value,
                        breakpoints=[0, 0.89, 1.78, 2.67, 3.56, 4.44, 5.33, 6.6, 7.0, 8],
                        table_data=[0, 4, 22, 66, 92, 97, 98, 98, 98, 98]):
        # Handle out-of-range inputs
        if input_value <= breakpoints[0]:
            return table_data[0]
        elif input_value >= breakpoints[-1]:
            return table_data[-1]
        # Find the right segment for interpolation
        for i in range(len(breakpoints) - 1):
            if breakpoints[i] <= input_value <= breakpoints[i + 1]:
                # Linear interpolation
                x0, x1 = breakpoints[i], breakpoints[i + 1]
                y0, y1 = table_data[i], table_data[i + 1]
                return y0 + (y1 - y0) * (input_value - x0) / (x1 - x0)
        return None

    def look_table_f1d(self, input_value,
                       rf=[0, 0.89, 1.78, 2.67, 3.56, 4.44, 5.33, 6.6, 7.0, 8],
                       z=[0, 4, 22, 66, 92, 97, 98, 98, 98, 98]):
        # Handle out-of-range inputs
        if input_value <= rf[0]:
            return z[0]
        elif input_value >= rf[-1]:
            return z[-1]
        # Find the right segment for interpolation
        for i in range(len(rf) - 1):
            if rf[i] <= input_value <= rf[i + 1]:
                x0, x1 = rf[i], rf[i + 1]
                y0, y1 = z[i], z[i + 1]
                return y0 + (y1 - y0) * (input_value - x0) / (x1 - x0)
        return None

    def look_table_r1d(self, input_value,
                       rf=[0, 0.89, 1.78, 2.67, 3.56, 4.44, 5.33, 6.6, 7.0, 8],
                       z=[0, 4, 22, 66, 92, 97, 98, 98, 98, 98]):
        # Handle out-of-range inputs
        if input_value <= rf[0]:
            return z[0]
        elif input_value >= rf[-1]:
            return z[-1]
        # Find the right segment for interpolation
        for i in range(len(rf) - 1):
            if rf[i] <= input_value <= rf[i + 1]:
                x0, x1 = rf[i], rf[i + 1]
                y0, y1 = z[i], z[i + 1]
                return y0 + (y1 - y0) * (input_value - x0) / (x1 - x0)
        return None

    def maximum_regenerative_torque_by_front_motor(self, velocity_related, w_fmotor):
        if w_fmotor <= 628.83:
            T_regen_fmotor = 250
        else:
            T_regen_fmotor = 250 * (658.32 / w_fmotor)
        T_max_regen_fmotor = (velocity_related / 100) * T_regen_fmotor
        return T_max_regen_fmotor

    def maximum_regenerative_torque_by_rear_motor(self, velocity_related, w_rmotor):
        if w_rmotor <= 628.83:
            T_regen_rmotor = 250
        else:
            T_regen_rmotor = 250 * (658.32 / w_rmotor)
        T_max_regen_rmotor = (velocity_related / 100) * T_regen_rmotor
        return T_max_regen_rmotor

    def required_wheel_braking_torque(self, front_braking_component, rear_braking_component, battery_output, T_brmax):
        required_T_brake_front = battery_output * (-1) * T_brmax * front_braking_component
        required_T_brake_rear = battery_output * (-1) * T_brmax * rear_braking_component
        return required_T_brake_front, required_T_brake_rear

    def output(self, required_T_brake_front, required_T_brake_rear, T_max_regen_fmotor, T_max_regen_rmotor):
        Myct = required_T_brake_front
        Mycs = required_T_brake_rear
        Mtst_toida = T_max_regen_fmotor
        Mtss_toida = T_max_regen_rmotor
        return Myct, Mycs, Mtst_toida, Mtss_toida
class BreakModel_subsystem_2:
    def __init__(self, myct, mycs, mtst_toida, mtss_toida,battery_output,velocity,acceleration):
        self.treq_f = myct
        self.treq_r = mycs
        self.tregen_max_f = mtst_toida
        self.tregen_max_r = mtss_toida
        self.battery_output = battery_output
        self.velocity = velocity
        self.acceleration = acceleration
    def braking_torque_distribution_strategy(self, treq_f, treq_r, tregen_max_f, tregen_max_r):
        Tregen_r = 0
        Tregen_f = 0
        Tmech_f = 0
        Tmech_r = 0
        Beta = 0.692
        Tz = treq_f + treq_r
        #case 1:
        if tregen_max_f >= treq_f:
            Tregen_f = treq_f
            Tmech_f = 0
            Tregen_r = treq_r
            Tmech_r = 0
        #case 2:
        if tregen_max_f < treq_f:
            Tregen_f = tregen_max_f
            Tmech_f = treq_f - Tregen_f
            Tmech_r = Tmech_f   * (1 - Beta) / Beta
            if (tregen_max_r + Tmech_r) >= treq_r:
                Tregen_r = treq_r - Tmech_f
                Tmech_r = 0
            elif (tregen_max_r + Tmech_r) < treq_r:
                Tregen_r = tregen_max_r
                Tmech_r = (treq_r - Tregen_r)
                Tmech_f = Tmech_r * Beta / (1 - Beta)
                if Tz >= Tmech_f and (tregen_max_f + Tmech_f) >= treq_f:
                    Tregen_f = treq_f - Tmech_f
                else:
                    Tregen_f = tregen_max_f
                    Tregen_r = tregen_max_r
                    Tmech_f = (Tz - Tregen_f - Tregen_r) * Beta
                    Tmech_r = (Tz - Tregen_f - Tregen_r) * (1 - Beta)
        vector_case2 = [Tmech_f, Tmech_r, Tregen_f, Tregen_r]
        return vector_case2            
    def signal_out(self, mtst_toida, constant, battery_output, velocity, vector_case2):
        vector_case1 = [0, mtst_toida * constant * 0.08, 0, mtst_toida]
        if -0.05 <= battery_output and battery_output < 0.01 and velocity > 0.5:
            signal_out = vector_case1
        else:
            signal_out = vector_case2 
        return signal_out
    def emgerency_braking(self, acceleration, vector_case1, vector_case2):
        z = abs(acceleration / 9.81)
        if z >= 0.927:
            tmech_f, tmech_r, tregen_f, tregen_r = vector_case1
        else:
            tmech_f, tmech_r, tregen_f, tregen_r = vector_case2
        return tregen_f, tmech_f, tregen_r, tmech_r
    def get_outputs(self, front_mechanical_braking_torque, rear_mechanical_braking_torque, front_regen_breaking_torque, rear_regen_breaking_torque):    
        T_fbbreq = front_regen_breaking_torque
        f_bt = front_mechanical_braking_torque
        T_rbbreq = rear_regen_breaking_torque
        r_bt = rear_mechanical_braking_torque
        return T_fbbreq, f_bt, T_rbbreq, r_bt
        