import pandas as pd
import numpy as np

class RearTireVehicleModel:
    def __init__(self, m, l_r, l_f, h, a, g,):
        self.m = m
        self.l_r = l_r
        self.l_f = l_f
        self.h = h
        self.a = a
        self.g = g
        self.f_zr = self.compute_vehicle_load()

    def compute_vehicle_load(self):
        return (self.m / (self.l_r + self.l_f)) * (self.g * self.l_r - self.h * self.a)

    def angular_velocity(self, r_mt, r_bt, f_xr, i_hs, n_hs, i_tlc, n_tlc, r_wh, i_df, J_whr, J_fd, J_gb, J_m,dt):
        e_ft = r_mt * i_hs * n_hs
        net_torque = self.rear_wheel_model(e_ft, r_bt, f_xr, i_tlc, n_tlc, r_wh, i_df)
        net_inertia = self.wheel_momentum_of_inertia(J_whr, J_fd, J_gb, i_tlc, J_m, i_hs)
        angular_acceleration = net_torque / net_inertia
        wr = angular_acceleration * dt
        if wr < 0.0000000001:
            wr = 0.0000000001
        return wr
    
    def rear_wheel_model(self, e_ft, r_bt, f_xr, i_tlc, n_tlc, r_wh, i_df):
        return (e_ft * i_tlc * n_tlc) - r_bt - (self.f_zr * r_wh * i_df) - f_xr * r_wh

    def wheel_momentum_of_inertia(self, J_whf, J_fd, J_gb, i_tlc, J_m, i_hs):
        return J_whf + J_fd + (J_gb * (i_tlc ** 2)) + (J_m * (i_tlc * i_hs) ** 2)

    def rear_omega_motor(self, wr, i_tlc, i_hs):
        angular_motor_velocity = wr * (i_tlc * i_hs)
        return angular_motor_velocity

    def rear_traction_tire_slip(self, wr, v, r_wh):
        return self.slip_ratio(wr, v, r_wh)

    def rear_traction_force(self, s):
        friction_coeff = self.friction_coefficient(s)
        return friction_coeff * self.f_zr

    def slip_ratio(self, wr, v, r_wh):
        TS = v - wr * r_wh
        MS_acceleration = wr * r_wh
        MS_braking = v
        if TS <= 0 and MS_acceleration >= abs(TS):
            s = TS / MS_acceleration
            return s
        elif TS > 0 and MS_braking >= abs(TS):
            s = TS / MS_braking
            return s

    def friction_coefficient(self, s):
        file_path = "tiremodel.xls"
        data = pd.read_excel(file_path)
        Slip = data.iloc[:, 0].values
        Roadmu = data.iloc[:, 1].values
        return np.interp(s, Slip, Roadmu)

    def get_outputs(self, wr,v, r_wh, i_tlc, i_hs, s):
        # Compute motor angular velocity from wheel function
        w_rmotor= self.rear_omega_motor(wr, i_tlc, i_hs)

        # Tire slip
        tire_slip = self.slip_ratio(wr, v, r_wh)
        # Traction force
        f_xr = self.rear_traction_force(s)

        return {
            "rear motor angular vel": w_rmotor,
            "rear tire slip": tire_slip,
            "rear tire traction force": f_xr,
            "rear tire vehicle load": self.f_zr
        }
def main():
    #input parameters
    J_m  =    0.01                      
    J_gb =    0.0196                   
    J_whf  =  0.815*2                  
    J_whr =   0.815*2                   
    J_fd =    0.07
    r_wh = 0.32535
    m = 1558.4
    l = 2.611
    l_f = l * 0.41
    l_r = l * 0.59
    h = 0.65
    g = 9.81
    a = float(input("Enter the acceleration: "))
    v = float(input("Enter the velocity: "))
    
    # Additional inputs needed for model
    f_mt = float(input("Enter the motor torque: "))
    f_bt = float(input("Enter the brake torque: "))
    i_hs = float(input("Enter high speed gear ratio: "))
    n_hs = float(input("Enter high speed gear efficiency: "))
    i_tlc = float(input("Enter torque converter gear ratio: "))
    n_tlc = float(input("Enter torque converter efficiency: "))
    i_df = float(input("Enter differential gear ratio: "))
    dt = float(input("Enter time step: "))
    r_bt = float(input("Enter the rolling resistance torque: "))
    wr = float(input("Enter the initial rear wheel angular velocity: "))
    s = float(input("Enter the initial rear tire slip: "))
    
    