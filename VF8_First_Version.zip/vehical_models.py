import numpy as np 

class VehicleModel():
    def __init__(self, f_zr, f_zf, f_xf,f_xr,v,id,f):
        self.v = v
        self.f_zr = f_zr
        self.f_zf = f_zf
        self.f_xf = f_xf
        self.f_xr = f_xr
        self.id = id
        self.f = f
    
    def front_rolling_resistance_and_ascent_resistance(self, f_zf, f_zr, id, f):
        Ff_Fd = (f_zf + f_zr) * (id + f)  
        return 1 / (Ff_Fd)
    def total_forces(self, f_zr, f_zf, f_xf, f_xr, id, f,v,r_o,C,A):
        f_sum = f_xf + f_xr - (0.5*np.power(v,2)*r_o*C*A) - self.front_rolling_resistance_and_ascent_resistance(f_zf, f_zr, id, f) 
        return f_sum
    def speed_output(self, f_zr, f_zf, f_xf, f_xr, id, f, v, ro, C, A, m, dt):
        def acceleration():
            a = self.total_forces(f_zr, f_zf, f_xf, f_xr, id, f, v, ro, C, A) / m
            return a
        
        def velocity():
            v_new = v + acceleration() * dt
            return v_new
        vehical_acceleration = acceleration()
        vehical_velocity = velocity()
        vehical_velcity_as_kilometer_per_hour = vehical_velocity * 3.6
        return vehical_acceleration, vehical_velocity, vehical_velcity_as_kilometer_per_hour
    def distance_output(self, f_zr, f_zf, f_xf, f_xr, id, f, v, r_o, C, A, m, dt, velocity=None):
        if velocity is None:
            _, velocity, _ = self.speed_output(f_zr, f_zf, f_xf, f_xr, id, f, v, r_o, C, A, m, dt)
        distance = velocity * dt
        return distance
    def get_outputs(self, r_o, C, A, m, dt):
        # Calculate acceleration, velocity, and distance
        acceleration, velocity = self.speed_output(self.f_zr, self.f_zf, self.f_xf, self.f_xr, self.id, self.f, self.v, r_o, C, A, m, dt)
        distance = self.distance_output(self.f_zr, self.f_zf, self.f_xf, self.f_xr, self.id, self.f, self.v, r_o, C, A, m, dt, velocity)
        
        return distance, acceleration, velocity

    